package com.hsbc.multiapp.db.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

import com.hsbc.au.base.convert.util.DataConvertUtil;
import com.hsbc.au.base.db.dto.GenericCondition;
import com.hsbc.au.base.db.util.HibernateGenericDao;
import com.hsbc.card.domain.common.Application;
import com.hsbc.card.domain.common.constants.IdentificationKeys;
import com.hsbc.card.domain.common.constants.IndividualKeys;
import com.hsbc.card.domain.common.constants.ProductGroupKeys;
import com.hsbc.card.domain.identity.Identifications;
import com.hsbc.multiapp.db.dto.TbMultiappApplication;
import com.hsbc.multiapp.db.dto.VAppAptAddrDecisionsUser;
import com.hsbc.multiapp.db.service.util.AppLeadSearchMapper;
import com.hsbc.multiapp.db.service.util.DBConstants;
import com.hsbc.multiapp.spi.dto.AppLeadSummary;
import com.hsbc.multiapp.spi.dto.AppSearchConditionDTO;
import com.hsbc.multiapp.spi.dto.AppSearchCriterionDTO;
import com.hsbc.multiapp.spi.dto.AppSearchParentDTO;
import com.hsbc.multiapp.spi.persist.AppSummaryService;
import com.hsbc.multiapp.spi.persist.util.MultiappDbSearchConfig;


public class AppSummaryServiceImpl implements AppSummaryService{
    protected HibernateGenericDao<TbMultiappApplication, String> applicationGenericDao;
    protected HibernateGenericDao<VAppAptAddrDecisionsUser, String> appAptAddHubViewGenericDao;

	public void setApplicationGenericDao(HibernateGenericDao<TbMultiappApplication, String> applicationGenericDao) {
		this.applicationGenericDao = applicationGenericDao;
	}
	public void setAppAptAddHubViewGenericDao(HibernateGenericDao<VAppAptAddrDecisionsUser, String> appAptAddHubViewGenericDao) {
		this.appAptAddHubViewGenericDao = appAptAddHubViewGenericDao;
	}

	@Override
	public int getCountByAppSearchCriterion(AppSearchCriterionDTO criterion, String countFieldName) {
		List<Criterion> conditionList = AppLeadSearchMapper.buildCriterionList(criterion);
		return applicationGenericDao.getCountByCriterions(conditionList, countFieldName);
	}

	@Override
	public int getCountByFromViewBySearchCriterion(AppSearchCriterionDTO criterion, String countFieldName) {
		List<Criterion> conditionList = AppLeadSearchMapper.buildCriterionList(criterion);
		return appAptAddHubViewGenericDao.getCountByCriterions(conditionList, countFieldName);
	}

	@Override
	public int[][] getCountByAppSearchCriterionMatrix(AppSearchCriterionDTO[][] dtoMatrix, String countFieldName) {
		if(dtoMatrix==null || dtoMatrix.length==0 || dtoMatrix[0].length==0){
			return null;
		}
		List<Criterion>[][] criterionMatrix = new ArrayList[dtoMatrix.length][dtoMatrix[0].length];
		for(int i = 0; i< criterionMatrix.length; i++){
			for(int j = 0; j< criterionMatrix[i].length; j++){
				if(dtoMatrix[i][j]!=null){
					criterionMatrix[i][j] = AppLeadSearchMapper.buildCriterionList(dtoMatrix[i][j]);
				}
//				JsonObjectUtil.saveObjectToJsonFile(dtoMatrix[i][j], "C:\\Users\\43725765.HBAP\\Desktop\\searchLog\\AppSearchCriterionDTO-"+i+"-"+j+".txt");
//				JsonObjectUtil.saveObjectToJsonFile(criterionMatrix[i][j], "C:\\Users\\43725765.HBAP\\Desktop\\searchLog\\Criterion-"+i+"-"+j+".txt");
			}
				
		}
		int[][] result = appAptAddHubViewGenericDao.getCountMatrixByCriterionsMatrix(criterionMatrix, countFieldName);
		return result;
	}

	@Override
	public List<Application> getApplicationSummaryByAppSearchCriterion(AppSearchCriterionDTO criterion) {
		// TODO Auto-generated method stub
		Application a1 = new Application();
		Application a2 = new Application();
		String[] productCodes1 = {"ABC", "DEF"};
		String[] productCodes2 = {"ABC", "GHI"};
		a1.setProductCodes(Arrays.asList(productCodes1));
		a2.setProductCodes(Arrays.asList(productCodes2));
		List<Application> result = new ArrayList<Application>();
		result.add(a1);
		result.add(a2);
		return result;
	}

//  result[0] = customers;
//	result[1] = needs;
//	result[2] = products;
//	result[3] = followUps;
//	result[4] = leadsReferrals;
//	result[5] = leadAppointments;
//	result[6] = leadInprogress;
//	result[7] = appDeposits;
//	result[8] = appCards;
//	result[9] = appPersonalLoans;
//	result[10] = appHomeLoans;
	@Override
	public int[] getAgentDashboard(AppSearchCriterionDTO searchCriterion) {
		int[] result = new int[11];
		//jie cao he zai, wo ye shi zui le
		String leadStatusAppointments = "'@AS','@AV','AGR'";
		String leadStatusReferral = "'REF'";
		String leadStatusInprogress = "'AT1','DIA','AT2','AT3','AC4','AC1','AFR','AFR','AFS','AFS','APS','ATM','CR2','ATR','AOP','CR1','@A1','DOC','CR4','CR5','CR3','@FP','FP1','PCY','BES','INT','NDI','QNM','R06','R07','R01','R05','R02','R09','R03','R04','TLM','ISR'";
		String noFurtherActions = "'A','D','AFW','AFW','CT5','BD2','BD4','PDB','ACL','BCL','CD7','CD3','CD6','AC5','CD0','CD5','DVL','PDC','PI2','PB2','VA2','INC','PCN','MCL','NDO','@R1','@R2','SQD','@A2','DLD','AB1','CL1','CTR','APD','CD1','@FW','FWR','FRC','GPS','GPS','CRV','@A3','SER','NDF','ERA','PSR','MKT','PTS','PT4','PSI','PT1','PT3','PT2','PT8','PT9','AB3','SQC','SRC','PI1','PB1','VA1','AB2'";
		String orAppNumbers = "'"+DataConvertUtil.convertArrayToDelimString(searchCriterion.getApplicationNumbers(), "','")+"'";

		String assignOrMonitor = searchCriterion.getMonitoredByStaff()!=null?"MONITORED_BY":"ASSIGNEDSTAFF";
		String staffId = searchCriterion.getMonitoredByStaff()!=null?searchCriterion.getMonitoredByStaff():searchCriterion.getAssignToUserId();
		
		String sqlCountCustomer = "select count(distinct CUSTOMER_ID) from V_APP_APT_ADDR_DECISIONS_USER where "+assignOrMonitor+"='"+staffId+"' and (APPLICATIONSTATUS not in (" + noFurtherActions+") or APPLICATIONSTATUS is null)";
		String sqlCountNeed ="select count(need) from V_APP_APT_ADDR_DECISIONS_USER where need is not null and "+assignOrMonitor+"='"+staffId+"' and applicanttype='M' and (APPLICATIONSTATUS not in (" + noFurtherActions+") or APPLICATIONSTATUS is null)";
		String sqlCountFollowup = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where "+assignOrMonitor+"='"+staffId+ "' and NEXT_FOLLOWUP_DATE<=TO_DATE('"+DataConvertUtil.convertDateToAUDateString(DataConvertUtil.getDateForAnyDaysBefore(new Date(), -1))+"','DD/MM/YYYY') and (APPLICATIONSTATUS not in (" + noFurtherActions+") or APPLICATIONSTATUS is null)";
		
		
		String sqlCountLeadsReferrals = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where dateappsubmitted is null and APPLICATION_TYPE = 'L' and "+assignOrMonitor+"='"+staffId+"' and APPLICATIONSTATUS in ("+leadStatusReferral+") and next_Followup_Date is null";
		String sqlCountLeadsAppointments = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where dateappsubmitted is null and APPLICATION_TYPE = 'L' and "+assignOrMonitor+"='"+staffId+"' and next_Followup_Date is not null and APPLICATIONSTATUS not in (" + noFurtherActions+")";
		String sqlCountLeadsInprogress = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where (APPLICATION_TYPE = 'L' and "+assignOrMonitor+"='"+staffId+"' and APPLICATIONSTATUS in ("+leadStatusInprogress+") and next_Followup_Date is null) or (APPLICATION_TYPE='A' and ((dateappsubmitted is null and (applicationstatus not in (" + noFurtherActions+") or applicationstatus is null)) or (applicationstatus is null and shortformcode is not null)) and "+assignOrMonitor+"='"+staffId+"')"; 
		String sqlCountAppDeposits = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where ("+assignOrMonitor+"='"+staffId+"' or applicationnumber in ("+orAppNumbers+")) and PRODUCT_GROUP = '"+ProductGroupKeys.PRODUCT_GROUP_DEPOSIT+"' and dateappsubmitted is not null and (APPLICATIONSTATUS not in (" + noFurtherActions+") or APPLICATIONSTATUS is null)";
		String sqlCountAppCards = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where ("+assignOrMonitor+"='"+staffId+"' or applicationnumber in ("+orAppNumbers+")) and PRODUCT_GROUP = '"+ProductGroupKeys.PRODUCT_GROUP_CREDIT_CARDS+"' and dateappsubmitted is not null and APPLICATIONSTATUS not in (" + noFurtherActions+")";
		String sqlCountAppPersonalLoans = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where ("+assignOrMonitor+"='"+staffId+"' or applicationnumber in ("+orAppNumbers+")) and PRODUCT_GROUP = '"+ProductGroupKeys.PRODUCT_GROUP_PERSONAL_LOAN+"' and dateappsubmitted is not null and APPLICATIONSTATUS not in (" + noFurtherActions+")";
		String sqlCountAppHomeLoans = "select count(distinct APPLICATIONNUMBER) from TB_MULTIAPP_APPLICATION where "+assignOrMonitor+"='"+staffId+"' and PRODUCT_GROUP = '"+ProductGroupKeys.PRODUCT_GROUP_PROPERTY+"' and APPLICATION_TYPE = 'A' and APPLICATIONSTATUS <>'C'";
		String unionAll = " union all ";
		
		StringBuffer sb = new StringBuffer();
		sb.append(sqlCountCustomer).append(unionAll)
		.append(sqlCountNeed).append(unionAll)
		.append(sqlCountFollowup).append(unionAll)
		.append(sqlCountLeadsReferrals).append(unionAll)
		.append(sqlCountLeadsAppointments).append(unionAll)
		.append(sqlCountLeadsInprogress).append(unionAll)
		.append(sqlCountAppDeposits).append(unionAll)
		.append(sqlCountAppCards).append(unionAll)
		.append(sqlCountAppPersonalLoans).append(unionAll)
		.append(sqlCountAppHomeLoans);

		
		List countList = applicationGenericDao.findByNativeSql(sb.toString());
		//customers
		result[0] = ((BigDecimal)countList.get(0)).intValue();

		//needs
		result[1] = ((BigDecimal)countList.get(1)).intValue();

		//products
		List<Criterion> criterionList = new ArrayList<Criterion>();
		if(searchCriterion.getAssignToUserId()!=null){
			criterionList.add(Restrictions.eq("assignedstaff", staffId));
		}else if(searchCriterion.getMonitoredByStaff()!=null){
			criterionList.add(Restrictions.eq("monitoredBy", staffId));
		}
		
		criterionList.add(Restrictions.ne("productCodes", "IS1"));
		if(searchCriterion.getStatusNotIn() != null && searchCriterion.getStatusNotIn().length > 0){
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(Restrictions.not(Restrictions.in("applicationstatus", searchCriterion.getStatusNotIn()))); 
			disjunction.add(Restrictions.isNull("applicationstatus")); 
			criterionList.add(disjunction);
		}

		
		Date t1 = new Date();
		List<TbMultiappApplication> applicationList = applicationGenericDao.findByCriteria(criterionList);
		Date t2 = new Date();
		System.out.println("+++" + (t2.getTime()-t1.getTime()));
//		List<String> productCodeSet = new ArrayList<String>();
		int productCount = 0;
		for(TbMultiappApplication tbMultiappApplication : applicationList){
			String products = tbMultiappApplication.getProductCodes();
			if(StringUtils.isNotEmpty(products))
				productCount+=DataConvertUtil.convertDelimStringToStringList(products, DBConstants.DB_DELIMITER).size();
		}
		result[2] = productCount;
		
		//followUps
		result[3] = ((BigDecimal)countList.get(2)).intValue();
		
		//leadsReferrals
		result[4] = ((BigDecimal)countList.get(3)).intValue();

		//leadAppointments
		result[5] = ((BigDecimal)countList.get(4)).intValue();

		//leadAppointments
		result[6] = ((BigDecimal)countList.get(5)).intValue();

		//appDeposits
		result[7] = ((BigDecimal)countList.get(6)).intValue();

		//appCards
		result[8] = ((BigDecimal)countList.get(7)).intValue();

		//appPersonalLoans
		result[9] = ((BigDecimal)countList.get(8)).intValue();

		//appHomeLoans
		result[10] = ((BigDecimal)countList.get(9)).intValue();

		return result;
	}
	
	@Override
	public List<AppLeadSummary> getAppLeadSummary(AppSearchCriterionDTO criterion) {
		List<Criterion> criteria = AppLeadSearchMapper.buildCriterionList(criterion);
		List<VAppAptAddrDecisionsUser> searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
		List<AppLeadSummary> appLeadSummary = new ArrayList<AppLeadSummary>();
		for(VAppAptAddrDecisionsUser dbo : searchResult){
			appLeadSummary.add(AppLeadSearchMapper.populateAppLeadSummary(dbo));
		}
		return appLeadSummary;
	}

	//Not yet completed but no harm
	public List<AppLeadSummary> getValidParentAppSummary2(AppSearchCriterionDTO criterion) {
		
		AppSearchCriterionDTO newCriterion = new AppSearchCriterionDTO();
		newCriterion.setApplicantType(IndividualKeys.TYPE_APPLICANT);
		newCriterion.setDateOfBirth(criterion.getDateOfBirth());
		newCriterion.setEmail(criterion.getEmail());
		newCriterion.setMotherMaidenName(criterion.getMotherMaidenName());
		newCriterion.setCdmDateFrom(DataConvertUtil.getDateForAnyDaysBefore(new Date(), 30));
		newCriterion.setHasParent(false);
		List<Criterion> criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
		List<VAppAptAddrDecisionsUser> searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
		
		if(searchResult==null){
			newCriterion = new AppSearchCriterionDTO();
			newCriterion.setApplicantType(IndividualKeys.TYPE_APPLICANT);
			newCriterion.setDateOfBirth(criterion.getDateOfBirth());
			newCriterion.setFirstName(criterion.getFirstName());
			newCriterion.setLastName(criterion.getLastName());
			newCriterion.setMobile(criterion.getMobile());
			newCriterion.setCdmDateFrom(DataConvertUtil.getDateForAnyDaysBefore(new Date(), 30));
			newCriterion.setHasParent(false);
			criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
			searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
		}
		if(searchResult==null){
			newCriterion = new AppSearchCriterionDTO();
			newCriterion.setApplicantType(IndividualKeys.TYPE_APPLICANT);
			newCriterion.setDateOfBirth(criterion.getDateOfBirth());
			newCriterion.setFirstName(criterion.getFirstName());
			newCriterion.setLastName(criterion.getLastName());
			newCriterion.setEmail(criterion.getEmail());
			newCriterion.setCdmDateFrom(DataConvertUtil.getDateForAnyDaysBefore(new Date(), 30));
			newCriterion.setHasParent(false);
			criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
			searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
		}
		if(searchResult==null){
			newCriterion = new AppSearchCriterionDTO();
			newCriterion.setApplicantType(IndividualKeys.TYPE_APPLICANT);
			newCriterion.setDateOfBirth(criterion.getDateOfBirth());
			newCriterion.setLastName(criterion.getLastName());
			newCriterion.setCdmDateFrom(DataConvertUtil.getDateForAnyDaysBefore(new Date(), 30));
			newCriterion.setHasParent(false);
			if (IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT.equals(criterion.getIdentityDocType()) && StringUtils.isNotBlank(criterion.getPassportnumber())) {
				newCriterion.setIdentityDocType(IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT);
				criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
				searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
			} else if (IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE.equals(criterion.getIdentityDocType()) && StringUtils.isNotBlank(criterion.getIdNumber())) {
				newCriterion.setIdentityDocType(IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE);
				newCriterion.setIdNumber(criterion.getIdNumber());
				criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
				searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
			}
				
		}
		if(searchResult==null){
			newCriterion = new AppSearchCriterionDTO();
			newCriterion.setApplicantType(IndividualKeys.TYPE_APPLICANT);
			newCriterion.setDateOfBirth(criterion.getDateOfBirth());
			newCriterion.setFirstName(criterion.getFirstName());
			newCriterion.setCdmDateFrom(DataConvertUtil.getDateForAnyDaysBefore(new Date(), 30));
			newCriterion.setHasParent(false);
			if (IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT.equals(criterion.getIdentityDocType()) && StringUtils.isNotBlank(criterion.getPassportnumber())) {
				newCriterion.setIdentityDocType(IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT);
				criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
				searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
			} else if (IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE.equals(criterion.getIdentityDocType()) && StringUtils.isNotBlank(criterion.getIdNumber())) {
				newCriterion.setIdentityDocType(IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE);
				newCriterion.setIdNumber(criterion.getIdNumber());
				criteria = AppLeadSearchMapper.buildCriterionList(newCriterion);
				searchResult = appAptAddHubViewGenericDao.findByCriteriaWithLimit(criteria, "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
			}
		}
		List<AppLeadSummary> appLeadSummary = new ArrayList<AppLeadSummary>();
		for(VAppAptAddrDecisionsUser dbo : searchResult){
			appLeadSummary.add(AppLeadSearchMapper.populateAppLeadSummary(dbo));
		}
		return appLeadSummary;
	}

	@Override
	public Map<List<String>, List<BigDecimal>> getHomeLoanDashboard(AppSearchCriterionDTO searchCriterion) {
		List<Criterion> criteria = AppLeadSearchMapper.buildCriterionList(searchCriterion);

		String[] countFieldNames = {"applicationstatus", "subStatus"};
		String[] sumFieldNames = {"creditdesiredamount"};
		Map<List<String>, List<BigDecimal>> statusMap = applicationGenericDao.getCountAndFieldValueByCriterions(criteria, countFieldNames, sumFieldNames);
//		JsonObjectUtil.saveObjectToJsonFile(statusMap, "result.txt");
//		String[][] result = new String[statusMap.size()][countFieldNames.length+1];
//		//build the count matrix
//		Iterator<Entry<List<String>, Integer>> itr = statusMap.entrySet().iterator();
//		int i = 0;
//		while (itr.hasNext()) {
//		    Map.Entry<List<String>, Integer> entry = itr.next();
//		    List<String> key = entry.getKey();
//		    result[i][0] = key.get(0);
//		    result[i][1] = key.get(1);
//		    result[i][2] = entry.getValue().toString();
//		    i++;
//		}
		
		return statusMap;
	}

	@Override
	public Map<List<String>, Integer> getCountsByAppSearchCriterionGroupByFields(AppSearchCriterionDTO searchCriterion, String[] groupByFields) {
		List<Criterion> criteria = AppLeadSearchMapper.buildCriterionList(searchCriterion);
		Map<List<String>, Integer> statusMap = applicationGenericDao.getCountAndFieldValueByCriterionsGroupByFields(criteria, groupByFields);
		return statusMap;
	}

	@Override
	public List<AppLeadSummary> getAppLeadSummaryByGenericCondiction(List<AppSearchConditionDTO> conditions) {
		List<GenericCondition> genericConditions = AppLeadSearchMapper.buildGenericCondition(conditions);
		List<VAppAptAddrDecisionsUser> searchResult = appAptAddHubViewGenericDao.findByGenericConditionListWithOrderAndLimit(genericConditions,  "lastupdatedate", MultiappDbSearchConfig.DEFAULT_APP_LEAD_SEARCH_RETURN_NUMBER);
		List<AppLeadSummary> appLeadSummary = new ArrayList<AppLeadSummary>();
		for(VAppAptAddrDecisionsUser dbo : searchResult){
			appLeadSummary.add(AppLeadSearchMapper.populateAppLeadSummary(dbo));
		}
		return appLeadSummary;
	}
	@Override
	public List<AppLeadSummary> getValidParentAppSummary(AppSearchParentDTO criterion) {

			Date dob = criterion.getDateOfBirth();
			boolean isDobExisted = dob != null && DataConvertUtil.convertDateToAUDateString(dob) != null;
			ArrayList applications = null;
			List<AppLeadSummary> resultList = null;
			
			if(isDobExisted) {
				String email = criterion.getEmail();
				String mobile = criterion.getMobile();
				
				String firstName = criterion.getFirstName();
				String lastName = criterion.getLastName();
				String motherMaidenName = criterion.getMotherMaidenName();

				String passNum = null;
				String licenseNum = null;
				String idType = null;
				
				StringBuffer basicQry = new StringBuffer();
				basicQry.append("select tmapp.applicationnumber, tmapp.parentid from TB_MULTIAPP_APPLICATION tmapp");
				basicQry.append(" ");
				basicQry.append("inner join TB_MULTIAPP_APPLICANT tmapnt on tmapnt.applicationnumber=tmapp.applicationnumber");
				basicQry.append(" ");
				basicQry.append("inner join MULTI_MAPSDECISION tmapd on tmapnt.applicationnumber=tmapd.applicationnumber and tmapnt.applicationnumber=tmapp.applicationnumber");
				basicQry.append(" ");
//				basicQry.append("inner join MULTI_HUBDECISION thubd on tmapnt.applicationnumber=thubd.applicationnumber and tmapnt.applicationnumber=thubd.applicationnumber");
//				basicQry.append(" ");
//				basicQry.append("where tmapnt.APPLICANTTYPE = 'M' and tmapd.cdmlastupdatedate >= trunc(SYSDATE) - 30");
				basicQry.append("where tmapd.cdmlastupdatedate >= trunc(SYSDATE) - 30 and tmapp.parentid is null and tmapp.applicationstatus='A'");
//				or thubd.lastupdatedate >= trunc(SYSDATE) - 30
				basicQry.append(" ");
				basicQry.append("and to_char(tmapnt.dateofbirth,'DD/MM/YYYY')='");
				basicQry.append(DataConvertUtil.convertDateToAUDateString(dob));
				basicQry.append("'");

				boolean isParentFound = false;
				
//				search by email and motherMaidenName
				if(!isParentFound && StringUtils.isNotBlank(email) && StringUtils.isNotBlank(motherMaidenName)) {
					
//					String queryStr = basicQry.toString() + " and tmapnt.emailaddress=:email and tmapp.mothermaidenname=:motherMaidenName order by cdmlastupdatedate desc";
					StringBuffer qrySB = new StringBuffer();
					qrySB.append(basicQry.toString());
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.emailaddress", email));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.mother_maiden_name", motherMaidenName));
					qrySB.append(" order by cdmlastupdatedate desc");
					applications = (ArrayList)applicationGenericDao.findByNativeSql(qrySB.toString());
					isParentFound = applications != null && !applications.isEmpty();
					
				}
				
//				search by firstName, lastName and mobile
				if(!isParentFound && StringUtils.isNotBlank(firstName) && StringUtils.isNotBlank(lastName) && StringUtils.isNotBlank(mobile)) {
					
//					String queryStr = basicQry.toString() + " and tmapnt.firstname=:firstName and tmpant.lastname=:lastName and tmpant.mobile=:mobile order by cdmlastupdatedate desc";
					StringBuffer qrySB = new StringBuffer();
					qrySB.append(basicQry.toString());
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.firstname", firstName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.lastname", lastName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.mobilephonenumber", mobile));
					qrySB.append(" order by cdmlastupdatedate desc");
					applications = (ArrayList)applicationGenericDao.findByNativeSql(qrySB.toString());
					isParentFound = applications != null && !applications.isEmpty();

				}
				
				// search by firstName, lastName and email
				if(!isParentFound && StringUtils.isNotBlank(firstName) && StringUtils.isNotBlank(lastName) && StringUtils.isNotBlank(email)) {
					
//					String queryStr = basicQry.toString() + " and tmapnt.firstname=:firstName and tmpant.lastname=:lastName and tmpant.emailaddress=:email order by cdmlastupdatedate desc";
					StringBuffer qrySB = new StringBuffer();
					qrySB.append(basicQry.toString());
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.firstname", firstName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.lastname", lastName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.emailaddress", email));
					qrySB.append(" order by cdmlastupdatedate desc");
					applications = (ArrayList)applicationGenericDao.findByNativeSql(qrySB.toString());
					isParentFound = applications != null && !applications.isEmpty();

				}
				
				Identifications id = criterion.getIdentifications();
				if (id!=null && IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT.equals(id.getMainPhotoIdType()) && id.getPassport() != null) {
					idType = IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT;
					passNum = id.getPassport().getNumber();
				} else if (id!=null &&  IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE.equals(id.getMainPhotoIdType()) && id.getDriversLicence() != null) {
					idType = IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE;
					licenseNum = id.getDriversLicence().getNumber();
				}
				// search by lastName, passPortNumber or driverLicenseNumber
				if(!isParentFound && StringUtils.isNotBlank(lastName) && idType != null) {

					StringBuffer qrySB = new StringBuffer();
					qrySB.append(basicQry.toString());
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.lastname", lastName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.identitydoctype", idType));
					
					if(IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT.equals(idType)) {
//						queryStr = basicQry.toString() + " and tmpant.lastname=:lastName and tmpant.identitydoctype=:idType and tmpant.passportnumber=:passNum order by cdmlastupdatedate desc";
						qrySB.append(" and ");
						qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.passportnumber", passNum));
					} else if(IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE.equals(idType)) {
//						queryStr = basicQry.toString() + " and tmpant.lastname=:lastName and tmpant.identitydoctype=:idType and tmpant.licensecardnumber=:licenseNum order by cdmlastupdatedate desc";
						qrySB.append(" and ");
						qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.licensenumber", licenseNum));
					}

					qrySB.append(" order by cdmlastupdatedate desc");
					applications = (ArrayList)applicationGenericDao.findByNativeSql(qrySB.toString());
					isParentFound = applications != null && !applications.isEmpty();
				}
				
				//firstName, passPortNumber or driverLicenseNumber
				if(!isParentFound && StringUtils.isNotBlank(firstName) && idType != null) {

					StringBuffer qrySB = new StringBuffer();
					qrySB.append(basicQry.toString());
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.firstname", firstName));
					qrySB.append(" and ");
					qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.identitydoctype", idType));

					if(IdentificationKeys.PHOTO_ID_TYPE_SHORT_PASSPORT.equals(idType)) {
//						queryStr = basicQry.toString() + " and tmpant.lastname=:lastName and tmpant.identitydoctype=:idType and tmpant.passportnumber=:passNum order by cdmlastupdatedate desc";
						qrySB.append(" and ");
						qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.passportnumber", passNum));
					} else if(IdentificationKeys.PHOTO_ID_TYPE_SHORT_AU_DRIVERS_LICENSE.equals(idType)) {
//						queryStr = basicQry.toString() + " and tmpant.lastname=:lastName and tmpant.identitydoctype=:idType and tmpant.licensecardnumber=:licenseNum order by cdmlastupdatedate desc";
						qrySB.append(" and ");
						qrySB.append(AppLeadSearchMapper.buildQueryString("tmapnt.licensenumber", licenseNum));
					}

					qrySB.append(" order by cdmlastupdatedate desc");
					applications = (ArrayList)applicationGenericDao.findByNativeSql(qrySB.toString());
					isParentFound = applications != null && !applications.isEmpty();
				}
				
				if(isParentFound) {
					resultList=new ArrayList<AppLeadSummary>();
					Iterator iterator = applications.iterator();
					AppLeadSummary result=null;
					while (iterator.hasNext()) {
					    Object[] row = (Object[]) iterator.next();
					    if(row!=null && row.length>-1){
					    	result = new AppLeadSummary();
				    		result.setRefNumber((String)row[0]);
				    		result.setParentId((String)row[1]);
				    		// ParentId should be empty
						    if(StringUtils.isNotBlank(result.getRefNumber()) && StringUtils.isBlank(result.getParentId())){
						    	resultList.add(result);
						    }
					    }
					}
				}
			}

			return resultList;
	}
}